// Server-only persistence for customizer templates.
import { createServiceRoleClient } from "@/lib/supabase/server";
import {
  normalizeCustomizerTemplate,
  prepareCustomizerTemplateForSave,
  templateFromRow,
  templateToRow,
} from "@/lib/customizer";
import { hydrateAdminAssetUrls, stripAdminAssetUrls } from "@/lib/customizer/server/admin-assets";

export async function getCustomizerTemplateByProductId(productId: string) {
  if (!productId) return null;
  const supabase = createServiceRoleClient();
  const { data, error } = await supabase
    .from("product_customizer_templates")
    .select("*")
    .eq("product_id", productId)
    .maybeSingle();

  if (error) throw error;
  return data ? hydrateAdminAssetUrls(templateFromRow(data), supabase) : null;
}

// Upsert a product's mutable draft. Draft saves and autosaves never create or
// advertise a new published version.
export async function saveCustomizerTemplate(productId: string, template: any) {
  if (!productId) return null;
  const supabase = createServiceRoleClient();

  const { data: existingRow, error: readError } = await supabase
    .from("product_customizer_templates")
    .select("*")
    .eq("product_id", productId)
    .maybeSingle();
  if (readError) throw readError;

  const existing = existingRow ? templateFromRow(existingRow) : null;
  // Reconcile layer<->field connections before persisting so customer-editable
  // layers always have a saved field and orphans are dropped.
  const next = normalizeCustomizerTemplate(prepareCustomizerTemplateForSave(template), existing || {});

  if (existing) {
    next.version = Number(existing.version || 1);
  } else {
    next.version = 1;
  }

  const row = templateToRow(productId, stripAdminAssetUrls(next));

  const { data, error } = await supabase
    .from("product_customizer_templates")
    .upsert(row, { onConflict: "product_id" })
    .select("*")
    .single();

  if (error) throw error;
  return hydrateAdminAssetUrls(templateFromRow(data), supabase);
}
